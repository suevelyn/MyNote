﻿using CTSWeb.SA.model;
using CTSWeb.Utility;
using PortalProxy;
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;


namespace CTSWeb.SA
{
    public partial class SA0104 : System.Web.UI.Page
    {
		string sUserName = "";
		string sCreator = "";
		
		public string ErrorMsg;
        //假資料
        XmlDocument eRtsQueryLedge5 = new XmlDocument();

        #region 分頁
        private int OnePageSize = 10;

		protected string liActive = "";

		private int CurrentState
		{
			get
			{
				object objState = ViewState["_CurrentState"];
				int _CurrentState = 0;
				if (objState == null)
				{
					_CurrentState = 0;
				}
				else
				{
					_CurrentState = (int)objState;
				}
				return _CurrentState;
			}
			set { ViewState["_CurrentState"] = value; }
		}
		private int CurrentPage
		{
			get
			{
				object objPage = ViewState["_CurrentPage"];
				int _CurrentPage = 0;
				if (objPage == null)
				{
					_CurrentPage = 0;
				}
				else
				{
					_CurrentPage = (int)objPage;
				}
				return _CurrentPage;
			}
			set { ViewState["_CurrentPage"] = value; }
		}
		private int fistIndex
		{
			get
			{

				int _FirstIndex = 0;
				if (ViewState["_FirstIndex"] == null)
				{
					_FirstIndex = 0;
				}
				else
				{
					_FirstIndex = Convert.ToInt32(ViewState["_FirstIndex"]);
				}
				return _FirstIndex;
			}
			set { ViewState["_FirstIndex"] = value; }
		}
		private int lastIndex
		{
			get
			{

				int _LastIndex = 0;
				if (ViewState["_LastIndex"] == null)
				{
					_LastIndex = 0;
				}
				else
				{
					_LastIndex = Convert.ToInt32(ViewState["_LastIndex"]);
				}
				return _LastIndex;
			}
			set { ViewState["_LastIndex"] = value; }
		}

		#endregion
		protected void Page_Load(object sender, EventArgs e)
        {

            //假資料
            eRtsQueryLedge5.Load(Server.MapPath("~/SA/xml/eRtsQueryLedge5.xml"));

            DateTime dt = DateTime.Now;
			
			dropAC.Items.Clear();
			Function.ChangePWD(Page);

			UserInfo iUser = GetTrading.GetUserInof();
			if (iUser == null && GetTrading.CookieValue("sAuthPass") != "1")
			{
				Response.Write(SAFunction.SiteLogOutJS());
				Response.End();
			}
			
			#region 客服系統使用
			try
			{
				CtsWebLogin sCtsWebLogin = (CtsWebLogin)Context.Handler;
				if (sCtsWebLogin != null)
					sUserID.Value = sCtsWebLogin.sUserID;
			}
			catch { }
            //eRtsQueryLedge
            APIResult apiResult = SAFunction.GetRtsQueryLedge(iUser.DefaultStockAID, (iUser != null) ? iUser.Creator : GetTrading.CookieValue("T_UID"), iUser.AccStockList[0].Key, "0", iUser.Creator,"");

            if (apiResult.rawData == null)
            {
                ShowNoSAccount();

			}
            else
            {
                if (sUserID.Value != "") { }
                //Function.GenDropAccountByID(dropAC, sUserID.Value);
                else
                    SAFunction.GenDropSettlementAccount(dropAC, apiResult.rawData,false);
            }

            #endregion
         
			if (dropAC.Items.Count != 0)
			{
				string sText = dropAC.SelectedItem.Text;
				int nIdx = sText.IndexOf("-");
				int nIdx2 = sText.IndexOf("-", nIdx + 1);
				if (nIdx2 > 0)
					sUserName = sText.Substring(nIdx2 + 1);
			}
            if (!Page.IsPostBack)
            {
				SD1_TextBox.Text = dt.AddDays(-7).ToString("yyyy/MM/dd"); 
				ED1_TextBox.Text = dt.ToString("yyyy/MM/dd");
				if (dropAC.Items.Count == 0)
                {
                    ShowNoSAccount();
                }
                else
                {
					ShowData(dropAC.SelectedValue, CurrentPage + 1, OnePageSize);
				}
            }
			btnQuery.Attributes["onclick"] = "javascript:return checksAID();return false;";

            lblQTime.Text = "資料更新 台北時間 " + SAFunction.TimeFormatTrans(apiResult.serverTime);

        }

        protected void ShowData(string sQuery, int skip, int num)
        {
            lblErr.Text = "";
            MsgError.Text = "";
            UserInfo iUser = GetTrading.GetUserInof();
			//@_@ API 
			APIResult apiResult = SAFunction.GetRtsLedgeDetail(iUser.DefaultStockAID, (iUser != null) ? iUser.Creator : GetTrading.CookieValue("T_UID"), "0", iUser.Creator,"", SD1_TextBox.Text.Replace("/", ""), ED1_TextBox.Text.Replace("/", ""), eRtsQueryLedge5.InnerXml);
			if(apiResult.rawData==null) { 
				DataTable dt = new DataTable();
				apiResult.rawData = dt;
			}
            if (apiResult.rawData.Rows.Count == 0) {

                MsgError.Text = "沒有資料";
				pagevisble(false);
			}
            else
            {
				apiResult.rawData.Columns.Add(new DataColumn("No", typeof(int)));
				apiResult.rawData.Columns.Add(new DataColumn("NegAmount", typeof(string),""));
				int CountRows= 0;
				foreach(DataRow dr_ in apiResult.rawData.Rows) 
				{
					CountRows += 1;
					dr_["No"] = CountRows;
					if (Convert.ToInt64(dr_["Amount"]) < 0)
					{
						dr_["NegAmount"] = Convert.ToDouble(dr_["Amount"]).ToString("N0").Substring(1);
						dr_["Amount"] = "";
					}
					else
					{
						dr_["Amount"] = Convert.ToDouble(dr_["Amount"]).ToString("N0");
					}	
				}
				double article_num = apiResult.rawData.Rows.Count;
				int TotalPages = Convert.ToInt16(Math.Ceiling(article_num / OnePageSize));
				ViewState["TotalPages"] = TotalPages;


				//DataView dv = new DataView(apiResult.rawData);
				DataView dv = new DataView(SAFunction.SplitDataTable(apiResult.rawData, skip, num));
				rptspec.DataSource = dv;
                rptspec.DataBind();
				doPaging();
				pagevisble(true);

			}
            lblQTime.Text = "資料更新 台北時間 " + SAFunction.TimeFormatTrans(apiResult.serverTime);

        }

        protected void rptspec_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            RepeaterItem row = e.Item;
            if (row.ItemType == ListItemType.Item || row.ItemType == ListItemType.AlternatingItem)
            {
				//DataRowView dv = (DataRowView)row.DataItem;
				DataRowView dv = (DataRowView)row.DataItem;
				Label LblTDate = (Label)e.Item.FindControl("LblTDate");
				string sTDate = dv["TDate"].ToString();
				LblTDate.Text = sTDate.Substring(0, 4)+ "/" + sTDate.Substring(4, 2) + "/" + sTDate.Substring(6, 2)+ "\r\n"+ sTDate.Substring(9, 2)+":"+sTDate.Substring(11, 2) + ":"+sTDate.Substring(13, 2) ;
				Label LblBalance = (Label)e.Item.FindControl("LblBalance");
				LblBalance.Text = (dv["Balance"] != null) ? Convert.ToDouble(dv["Balance"]).ToString("N0") : "0";			
			}
        }

        protected void btnQuery_Click(object sender, EventArgs e)
        {
			SD_Calendar1.Visible = false;
			ED_Calendar1.Visible = false;
			DateTime today= DateTime.Now;
		
			if (dropAC.Items.Count == 0)
            {
                ShowNoSAccount();
            }
            else if(Convert.ToDecimal(SD1_TextBox.Text.Replace("/", "")) > Convert.ToDecimal(ED1_TextBox.Text.Replace("/", ""))) 
			{
				DateCheck(1);//起始日期不得大於結束日期
			}
			else if (Convert.ToDecimal(today.AddMonths(-6).ToString("yyyyMMdd")) > Convert.ToDecimal(SD1_TextBox.Text.Replace("/", "")))
			{
				DateCheck(2);//最多查詢半年內資料
			}
			else if (DateTime.Compare(DateTime.ParseExact(ED1_TextBox.Text.Replace("/", ""), "yyyyMMdd", System.Globalization.CultureInfo.CurrentCulture).AddMonths(-3), DateTime.ParseExact(SD1_TextBox.Text.Replace("/", ""), "yyyyMMdd", System.Globalization.CultureInfo.CurrentCulture)) > 0)
			{
				DateCheck(3);//最大查詢區間為3個月內
			}
			else
            {
				ShowData(dropAC.SelectedValue, CurrentPage + 1, OnePageSize);
			}
        }
		//日曆查詢判斷
		private void DateCheck(int category)
		{
			DateTime today = DateTime.Now;
			StringBuilder aScript_ = new StringBuilder();
			if (category==1)
			{
				aScript_.Append("<script language='javascript'>");
				aScript_.Append("alert('起始日期不得大於結束日期');\n");
				aScript_.Append("</script>");
				Page.RegisterStartupScript("alert", aScript_.ToString());
			}
			else if (category == 2)
			{
				aScript_.Append("<script language='javascript'>");
				aScript_.Append("alert('最多查詢半年內資料，查詢區間為3個月!!');\n");
				aScript_.Append("</script>");
				Page.RegisterStartupScript("alert", aScript_.ToString());
			}
			else if (category == 3)
			{
				aScript_.Append("<script language='javascript'>");
				aScript_.Append("alert('最大查詢區間為3個月內');\n");
				aScript_.Append("</script>");
				Page.RegisterStartupScript("alert", aScript_.ToString());
			}
		}
		private void ShowNoSAccount()
        {
            
            StringBuilder aScript = new StringBuilder();
            aScript.Append("<script language='javascript'>");
            aScript.Append("alert('沒有交易帳號');\n");
            aScript.Append("</script>");
            Page.RegisterStartupScript("alert", aScript.ToString());
			pagevisble(false);

		}

		protected void SD2_ImageButton_Click(object sender, ImageClickEventArgs e)
		{
			SD_Calendar1.Visible = true;
			ED_Calendar1.Visible = false;
		}

		protected void ED2_ImageButton_Click(object sender, ImageClickEventArgs e)
		{
			ED_Calendar1.Visible = true;
			SD_Calendar1.Visible = false;
		}

		protected void SD_Calendar1_SelectionChanged(object sender, EventArgs e)
		{
			string startdate = SD_Calendar1.SelectedDate.ToString("yyyy/MM/dd");
			SD1_TextBox.Text = startdate;
			SD_Calendar1.Visible = false;
		}

		protected void EC_Calendar1_SelectionChanged(object sender, EventArgs e)
		{
			string enddate = ED_Calendar1.SelectedDate.ToString("yyyy/MM/dd");
			ED1_TextBox.Text = enddate;
			ED_Calendar1.Visible = false;
		}
		//頁面
		protected void rptPaging_ItemCommand(object source, RepeaterCommandEventArgs e)
		{
			if (GetTrading.CookieValue("EnCodeSA_SubAcc") == "" ||  GetTrading.CookieValue("EnCodeSA_SubAcc") == "all")
			{
				//dropAC.SelectedValue = "all";
			}
			else
			{
				dropAC.SelectedValue = GetTrading.CookieValue("EnCodeSA_SubAcc");
			}
			if (e.CommandName.Equals("Paging"))
			{
				CurrentPage = Convert.ToInt16(e.CommandArgument.ToString());
				ShowData(dropAC.SelectedValue, CurrentPage + 1, OnePageSize);
			}
		}

		protected void rptPaging_ItemDataBound(object sender, RepeaterItemEventArgs e)
		{
			if (GetTrading.CookieValue("EnCodeSA_SubAcc") == "" ||  GetTrading.CookieValue("EnCodeSA_SubAcc") == "all")
			{
				//dropAC.SelectedValue = "all";
			}
			else
			{
				dropAC.SelectedValue = GetTrading.CookieValue("EnCodeSA_SubAcc");
			}
			LinkButton lnkbtnPage = (LinkButton)e.Item.FindControl("lb_PAGENUM");

			if (lnkbtnPage.CommandArgument.ToString() == CurrentPage.ToString())
			{
				lnkbtnPage.Enabled = false;
				lnkbtnPage.Style.Add("fone-size", "14px");
				lnkbtnPage.Font.Bold = true;
				//liActive = "active";
			}
			else
			{
				// liActive = "";
			}


		}


		protected void lbtnPrevious_Click(object sender, EventArgs e)
		{
			if (CurrentPage != 0)
			{
				CurrentPage -= 1;
				int state = CurrentState;
				ShowData(dropAC.SelectedValue, CurrentPage + 1, OnePageSize);
			}

		}

		protected void lbtnNext_Click(object sender, EventArgs e)
		{
			if (CurrentPage + 1 < Convert.ToInt32(ViewState["TotalPages"]))
			{
				CurrentPage += 1;
				int state = CurrentState;
				ShowData(dropAC.SelectedValue, CurrentPage + 1, OnePageSize);
			}

		}

		private void doPaging()
		{
			DataTable dt = new DataTable();
			dt.Columns.Add("PageIndex");
			dt.Columns.Add("PageNum");

			fistIndex = CurrentPage - 5;


			if (CurrentPage >= 3)
			{
				lastIndex = CurrentPage + 3;
				fistIndex = CurrentPage - 2;
			}
			else
			{
				lastIndex = 5;
			}
			if (lastIndex >= Convert.ToInt32(ViewState["TotalPages"]))
			{
				lastIndex = Convert.ToInt32(ViewState["TotalPages"]);
				fistIndex = lastIndex - 5;
			}

			if (fistIndex < 0)
			{
				fistIndex = 0;
			}

			for (int i = fistIndex; i < lastIndex; i++)
			{
				DataRow dr = dt.NewRow();
				dr[0] = i;
				dr[1] = i + 1;
				dt.Rows.Add(dr);
			}
			try
			{
				rptPaging.DataSource = dt;
				rptPaging.DataBind();
			}
			catch (Exception e)
			{
				throw;
			}

		}
		private void pagevisble(bool visble)
		{
				lbtnPrevious.Visible = visble;
				lbtnLast.Visible = visble;	
		}
	}
}