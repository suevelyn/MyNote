﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace CTSWeb.SA.model
{
    public class APIResult
    {
        public DataTable rawData { get; set; }
        public string serverTime { get; set; }
        public string errorName { get; set; }
    }
}