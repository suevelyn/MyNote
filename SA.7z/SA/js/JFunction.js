function CheckBrowser(){
    var userAgent = navigator.userAgent,
               rMsie = /(msie\s|trident.*rv:)([\w.]+)/,
               rFirefox = /(firefox)\/([\w.]+)/,
               rOpera = /(opera).+version\/([\w.]+)/,
               rChrome = /(chrome)\/([\w.]+)/,
               rSafari = /version\/([\w.]+).*(safari)/;
    var browser;
    var version;
    var ua = userAgent.toLowerCase();
    function uaMatch(ua) {
        var match = rMsie.exec(ua);
        if (match != null) {
            return { browser: "IE", version: match[2] || "0" };
        }
        var match = rFirefox.exec(ua);
        if (match != null) {
            return { browser: match[1] || "", version: match[2] || "0" };
        }
        var match = rOpera.exec(ua);
        if (match != null) {
            return { browser: match[1] || "", version: match[2] || "0" };
        }
        var match = rChrome.exec(ua);
        if (match != null) {
            return { browser: match[1] || "", version: match[2] || "0" };
        }
        var match = rSafari.exec(ua);
        if (match != null) {
            return { browser: match[2] || "", version: match[1] || "0" };
        }
        if (match != null) {
            return { browser: "", version: "0" };
        }
    }
    var browserMatch = uaMatch(userAgent.toLowerCase());
    if (browserMatch.browser) {
        browser = browserMatch.browser;
        version = browserMatch.version;
    }
    return browser
}

function CheckBrowser2(){
    var userAgent = navigator.userAgent,
               rMsie = /(msie\s|trident.*rv:)([\w.]+)/,
               rFirefox = /(firefox)\/([\w.]+)/,
               rOpera = /(opera).+version\/([\w.]+)/,
               rChrome = /(chrome)\/([\w.]+)/,
               rSafari = /version\/([\w.]+).*(safari)/;
    var browser;
    var version;
    var ua = userAgent.toLowerCase();
    function uaMatch(ua) {
        var match = rMsie.exec(ua);
        if (match != null) {
            return { browser: "IE", version: match[2] || "0" };
        }
        var match = rFirefox.exec(ua);
        if (match != null) {
            return { browser: match[1] || "", version: match[2] || "0" };
        }
        var match = rOpera.exec(ua);
        if (match != null) {
            return { browser: match[1] || "", version: match[2] || "0" };
        }
        var match = rChrome.exec(ua);
        if (match != null) {
            return { browser: match[1] || "", version: match[2] || "0" };
        }
        var match = rSafari.exec(ua);
        if (match != null) {
            return { browser: match[2] || "", version: match[1] || "0" };
        }
        if (match != null) {
            return { browser: "", version: "0" };
        }
    }
    var browserMatch = uaMatch(userAgent.toLowerCase());
    if (browserMatch.browser) {
        browser = browserMatch.browser;
        version = browserMatch.version;
    }
    return { browser: browser, version: version };
}


function CASignToObj(sCAID,sCAKey,myobj){    
    var str = "";
    try
    {
        str = document.getElementById("HidData2Sign").value;
    }
    catch(e)
    {
        str = window.opener.document.getElementById("HidData2Sign").value;
    }
    
    str = str.replace(/(?:\\[rn]|[\r\n]+)+/g, "");
    //str = str.replace(/(?:\\[rn]|[\r\n]+)+/g, "");
    
    if(str == "")
        return false;
    
    var sErrCode = "";
    var sErrMsg = "";
	
    var sSignature = "";
    var sData2Sign = "";
    var tempSignature = "";
	
    sData2Sign = "x=" + str;
    //alert(sData2Sign);
	
    try
    {
        // �ŧi PKI ����
        var jKit = new jrsysPKI();
    	
        // �ϥΨ����
        // ����檺���D�A�H,���Ϲj
        var contentHeader = document.getElementById("HidShowHead").value;
        // ����椺�e�A�H,���Ϲj
        // �h����ƪ��ܡA�H;���걵
        var showContent = document.getElementById("HidShowText").value;

        // ���w CN ñ��
        // �Ѽ� 1: ���j�M��CN
        // �Ѽ� 2: ���j�M��Issuer Name�A�i���Ŧr��
        // �Ѽ� 3: �i��ñ���B�⪺���
        // �Ѽ� 4: �ϥΨ�������
        // �^�� : P7 SignedData ��� (Hex Encode)

        // �]�w P7 ñ����Ƥ��]�t����A�w�]�O���]�t����
        //jKit.signedDataWithContent = false;
    
        var hexSignedData = jKit.rsaSignedDataUseCn(sCAKey, "", sData2Sign, false, contentHeader, showContent);
        if (hexSignedData != "") 
        {
            // PKCS#7 ñ�����G
	        // �N hex ��X�� base64
	        //var tempSignature = jKit.hexToB64(hexSignedData);
	        var tempSignature = hexSignedData;
	        sSignature += tempSignature ;//+ "#";
        }
        else
        {
            if(jKit.rv != 0)
                alert("���ҿ��~\n���~�N�X�G" + jKit.rv + "\n" + "���~�T���G" + showErrorCode(jKit.rv));
                return false;
        }
    }
    catch(e)
    {
        sSignature += "#";
        alert ("�L�kŪ�����ҡA�Цw�˾��ҤΤ���!");
        return false;
    }
	
    //if(sSignature.length != 0)
    //    sSignature = sSignature.substring(0,sSignature.length-1);

    if (sSignature=="")
      return false;
        
    try
    {
        document.getElementById("HidSignature").value = sSignature;
    }
    catch(e)
    {
        window.opener.document.getElementById("HidSignature").value = sSignature;
    }
    
    if (typeof(Send) != 'undefined')
      Send();
    
    return true;
}


//20170704 ���ӫ�s������
function compareCom(installVer, currentVer) {
    var a = installVer.split(".");
    var b = currentVer.split(".");
    var c = 1000000000 * (100 + a[0]) + 1000000 * (100 + a[1]) + 1000 * (100 + a[2]) + 1 * (100 + a[3]);
    var d = 1000000000 * (100 + b[0]) + 1000000 * (100 + b[1]) + 1000 * (100 + b[2]) + 1 * (100 + b[3]);
    if (c >= d)
        return true;
    else
        return false;
}

function RsaSignedDataUseCn(CN, Data2BSignHex,id) {
    var _Id = id;

    var IssuerName = '';
    console.log(_Id);

    var myPKI = new jPKI();
    myPKI.GetToolInfo(function (returnValue) {
        if (myPKI.rv === 0) {
            var tmp = returnValue.split(";");
            // 1.0.0.41 �����ץ� signedDataWithContent �Ѽ�
            if (compareCom(tmp[1], "1.0.0.41")) {
                myPKI.signedDataWithContent = true;
            } else {
                // �w�����󪩥��p�� 1.0.0.41
                myPKI.signedDataWithContent = false;
            }
        } else {
            // �w�����󪩥��p�� 1.0.0.36
            myPKI.signedDataWithContent = false;
        }
    });
    myPKI.RsaSignedDataUseCn(CN, IssuerName, Data2BSignHex, function (returnValue) {

        if (myPKI.rv == 0) {
            console.log(returnValue);
            showMsg = returnValue;
            document.getElementById("HidSignature").value = showMsg;
            console.log(showMsg)
            //$('#<%= HidSignature.ClientID %>').val(showMsg);

        } else {
            console.log(returnValue);
            showMsg = myPKI.errorMsg;
            document.getElementById("HidSignature").value = showMsg = showMsg;
   
          //  $('#<%= HidSignature.ClientID %>').val(showMsg);
        }
        //document.getElementById("BtCA").click();
        document.getElementById(_Id+"_BtCA").click();
        
        //document.getElementById("btnMoneyOut").click();
        //$('#<%= NextButton.ClientID %>').click();
    });
}

function RsaSignedDataUseCn1(CN, Data2BSignHex, id) {
    var _Id = id;

    var IssuerName = '';
    console.log(_Id);

    var myPKI = new jPKI();
    myPKI.GetToolInfo(function (returnValue) {
        if (myPKI.rv === 0) {
            var tmp = returnValue.split(";");
            // 1.0.0.41 �����ץ� signedDataWithContent �Ѽ�
            if (compareCom(tmp[1], "1.0.0.41")) {
                myPKI.signedDataWithContent = true;
            } else {
                // �w�����󪩥��p�� 1.0.0.41
                myPKI.signedDataWithContent = false;
            }
        } else {
            // �w�����󪩥��p�� 1.0.0.36
            myPKI.signedDataWithContent = false;
        }
    });
    myPKI.RsaSignedDataUseCn(CN, IssuerName, Data2BSignHex, function (returnValue) {

        if (myPKI.rv == 0) {
            console.log(returnValue);
            showMsg = returnValue;
            document.getElementById("HidSignature").value = showMsg;
            console.log(showMsg)
            //$('#<%= HidSignature.ClientID %>').val(showMsg);

        } else {
            console.log(returnValue);
            showMsg = myPKI.errorMsg;
            document.getElementById("HidSignature").value = showMsg = showMsg;

            //  $('#<%= HidSignature.ClientID %>').val(showMsg);
        }
        //document.getElementById("BtCA").click();
        document.getElementById(_Id + "_BtCA1").click();

        //document.getElementById("btnMoneyOut").click();
        //$('#<%= NextButton.ClientID %>').click();
    });
}

