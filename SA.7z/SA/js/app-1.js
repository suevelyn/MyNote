jQuery(function($){

$("p.Question").css({cursor:"pointer"}).click(function(){

$(this).next().slideToggle("slow");

});

});