﻿using CTSWeb.SA.model;
using CTSWeb.Utility;
using PortalProxy;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;


namespace CTSWeb.SA
{
    public partial class SA0101_APP : System.Web.UI.Page
    {
        string sUserName = "";
        string sCreator = "";
        //int itotCount = 0;
        public string ErrorMsg;

        protected void Page_Load(object sender, EventArgs e)
        {

            //ShowData();
            dropAC.Items.Clear();
            Function.ChangePWD(Page);
            //PageHead1.PageID = "SA0101";

            UserInfo iUser = GetTrading.GetUserInof();
            if (iUser == null && GetTrading.CookieValue("sAuthPass") != "1")
            {
                Response.Write(SAFunction.SiteLogOutJS());
                Response.End();
            }


            #region 客服系統使用
            try
            {
                CtsWebLogin sCtsWebLogin = (CtsWebLogin)Context.Handler;
                if (sCtsWebLogin != null)
                    sUserID.Value = sCtsWebLogin.sUserID;
            }
            catch { }
            //eRtsQueryLedge
            APIResult apiResult = SAFunction.GetRtsQueryLedge(iUser.DefaultStockAID, (iUser != null) ? iUser.Creator : GetTrading.CookieValue("T_UID"), iUser.AccStockList[0].Key, "0", iUser.Creator, "");

            if (apiResult.rawData == null)
            {
                ShowNoSAccount();
            }
            else
            {
                if (sUserID.Value != "") { }
                //Function.GenDropAccountByID(dropAC, sUserID.Value);
                else
                    SAFunction.GenDropSettlementAccount(dropAC, apiResult.rawData,true);
            }

            #endregion

            if (dropAC.Items.Count != 0)
            {
                string sText = dropAC.SelectedItem.Text;
                int nIdx = sText.IndexOf("-");
                int nIdx2 = sText.IndexOf("-", nIdx + 1);
                if (nIdx2 > 0)
                    sUserName = sText.Substring(nIdx2 + 1);
            }
            if (!Page.IsPostBack)
            {
                if (dropAC.Items.Count == 0)
                {
                    ShowNoSAccount();
                }
                else
                {
                    ShowData();
                }
            }
            btnQuery.Attributes["onclick"] = "javascript:return checksAID();return false;";

            lblQTime.Text = "台北時間" + SAFunction.TimeFormatTrans(apiResult.serverTime) + "更新";

        }

        protected void ShowData()
        {
            lblErr.Text = "";
            MsgError.Text = "";
            UserInfo iUser = GetTrading.GetUserInof();

            APIResult apiResult = SAFunction.GetRtsQueryLedge(iUser.DefaultStockAID, (iUser != null) ? iUser.Creator : GetTrading.CookieValue("T_UID"), iUser.AccStockList[0].Key, "0", iUser.Creator, "");

            if (apiResult.rawData.Rows.Count == 0)
            {

                MsgError.Text = "沒有資料";
            }
            else
            {
                DataView dv = new DataView(apiResult.rawData);
                rptspec.DataSource = dv;
                rptspec.DataBind();


            }
            lblQTime.Text = "台北時間" + SAFunction.TimeFormatTrans(apiResult.serverTime)+ "更新";

        }

        protected void rptspec_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            RepeaterItem row = e.Item;
            if (row.ItemType == ListItemType.Item || row.ItemType == ListItemType.AlternatingItem)
            {

                DataRowView dv = (DataRowView)row.DataItem;
                Label Balance = (Label)e.Item.FindControl("lblBalance");
                Balance.Text = (dv["Balance"] != null) ? Convert.ToDouble(dv["Balance"]).ToString("N0") : "0";
                //Balance.Text = (dv["Balance"] != null) ? Convert.ToDouble(dv["Balance"]).ToString("N2") : "0";
            }

        }

        protected void btnQuery_Click(object sender, EventArgs e)
        {

            if (dropAC.Items.Count == 0)
            {
                ShowNoSAccount();
            }
            else
            {
                ShowData();
            }
        }

        private void ShowNoSAccount()
        {
            //lblErr.Text = "沒有交易帳號";
            StringBuilder aScript = new StringBuilder();
            aScript.Append("<script language='javascript'>");
            aScript.Append("alert('沒有交易帳號');\n");
            aScript.Append("</script>");
            Page.RegisterStartupScript("alert", aScript.ToString());
        }
    }
}