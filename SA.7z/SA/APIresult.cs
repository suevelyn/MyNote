﻿namespace CTSWeb.SA
{
    internal class APIresult
    {
    }
}