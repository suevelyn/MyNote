﻿using CTSWeb.SA.model;
using CTSWeb.Utility;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using System.Web.UI.WebControls;
using System.Xml;

namespace CTSWeb
{
    public class SAFunction
    {

        //分戶帳出入金功能
        public static APIResult GetSetLedgeTrade(string Account, string UserID, string Key, string CID, string Status, string OID, string Amount , string Currency,
            string BID1,string SubAcc1, string BID2, string SubAcc2, string Memo, string CAKey, string DataToSign, string DataSignature, string CAType, string CAID)
        {
            DataTable dt = new DataTable();
            string APIName = "eSetLedgeTrade.aspx";
            string URL = ConfigurationSettings.AppSettings["TSServerPath"].ToString() + APIName;
            WebClient webClient = new WebClient();
            NameValueCollection formData = new NameValueCollection();

            formData.Clear();
            formData["u0"] = Account;
            formData["u1"] = UserID;
            formData["u3"] = Key;
            formData["u5"] = Function.GetClientIP();
            formData["u6"] = CID;
            formData["p0"] = Status;
            formData["p1"] = OID;
            formData["p2"] = Amount;
            formData["p3"] = Currency;
            formData["p4"] = BID1;
            formData["p5"] = SubAcc1;
            formData["p6"] = BID2;
            formData["p7"] = SubAcc2;
            formData["p8"] = Memo;
            formData["ca0"] = CAKey;
            formData["ca1"] = DataToSign;
            formData["ca2"] = DataSignature;
            formData["ca3"] = CAType;
            formData["ca5"] = CAID;

            byte[] responseBytes = webClient.UploadValues(URL, "POST", formData);
            string resultAuthTicket = Encoding.Default.GetString(responseBytes);
            webClient.Dispose();

            StringReader sr = new StringReader(resultAuthTicket);
            DataSet ds = new DataSet();
            ds.ReadXml(sr);
            return DataSetToAPIResult(ds);
        }


        //分戶帳出入金查詢
        public static APIResult GetQueryLedgeTrade(string Account, string UserID, string Key, string CID, string IDs,string SubAcc)
        {
            DataTable dt = new DataTable();
            string APIName = "eQueryLedgeTrade.aspx";
            string URL = ConfigurationSettings.AppSettings["TSServerPath"].ToString() + APIName;
            WebClient webClient = new WebClient();
            NameValueCollection formData = new NameValueCollection();

            formData.Clear();
            formData["u0"] = Account;
            formData["u1"] = UserID;
            formData["u3"] = Key;
            formData["u5"] = Function.GetClientIP();
            formData["u6"] = CID;
            formData["p0"] = IDs;
            formData["p1"] = SubAcc;

            byte[] responseBytes = webClient.UploadValues(URL, "POST", formData);
            string resultAuthTicket = Encoding.Default.GetString(responseBytes);
            webClient.Dispose();

            StringReader sr = new StringReader(resultAuthTicket);
            DataSet ds = new DataSet();
            ds.ReadXml(sr);
            return DataSetToAPIResult(ds);
        }


        public static APIResult GetQueryLedgeTrade(string Account, string UserID, string Key, string CID, string IDs, string SubAcc,string xml) {
            DataTable dt = new DataTable();
            string APIName = "eQueryLedgeTrade.aspx";
            string URL = ConfigurationSettings.AppSettings["TSServerPath"].ToString() + APIName;
            WebClient webClient = new WebClient();
            NameValueCollection formData = new NameValueCollection();

            formData.Clear();
            formData["u0"] = Account;
            formData["u1"] = UserID;
            formData["u3"] = Key;
            formData["u5"] = Function.GetClientIP();
            formData["u6"] = CID;
            formData["p0"] = IDs;
            formData["p1"] = SubAcc;

            byte[] responseBytes = webClient.UploadValues(URL, "POST", formData);
            string resultAuthTicket = Encoding.Default.GetString(responseBytes);
            webClient.Dispose();

            StringReader sr = new StringReader(resultAuthTicket);
            DataSet ds = new DataSet();
            if (!string.IsNullOrWhiteSpace(xml)) {
                ds = JoinXMLGetQueryLedgeTrade(xml);
            } else {
                ds.ReadXml(sr);
            }
            return DataSetToAPIResult(ds);
        }

        public static DataSet JoinXMLGetQueryLedgeTrade(string xmlData) {
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.XmlResolver = null;
            DataSet ds = new DataSet();
            xmlDoc.LoadXml(xmlData);
            if (xmlDoc.SelectNodes("Result/Data").Count > 0) {
                DataTable dt = new DataTable();
                dt.TableName = "Row";
                dt.Columns.Add(new DataColumn("OID", typeof(string)));
                dt.Columns.Add(new DataColumn("TDateTime", typeof(string)));
                dt.Columns.Add(new DataColumn("BID", typeof(string)));
                dt.Columns.Add(new DataColumn("SubAcc", typeof(string)));
                dt.Columns.Add(new DataColumn("CurrencyCode", typeof(string)));
                dt.Columns.Add(new DataColumn("Currency", typeof(string)));
                dt.Columns.Add(new DataColumn("Amout", typeof(string)));
                dt.Columns.Add(new DataColumn("Memo", typeof(string)));
                dt.Columns.Add(new DataColumn("PlatformCode", typeof(string)));
                dt.Columns.Add(new DataColumn("Platform", typeof(string)));
                dt.Columns.Add(new DataColumn("State", typeof(string)));
                dt.Columns.Add(new DataColumn("Status", typeof(string)));

                DataRow dr = null;
                XmlNodeList nodeRow = xmlDoc.SelectNodes("Result/Data/Row");
                foreach (XmlNode oData in nodeRow) {
                    XmlElement elem = (XmlElement)oData;
                    dr = dt.NewRow();
                    dr[0] = elem.Attributes["OID"].Value;
                    dr[1] = elem.Attributes["TDateTime"].Value;
                    dr[2] = elem.Attributes["BID"].Value;
                    dr[3] = elem.Attributes["SubAcc"].Value;
                    dr[4] = elem.Attributes["CurrencyCode"].Value;
                    dr[5] = elem.Attributes["Currency"].Value;
                    dr[6] = elem.Attributes["Amout"].Value;
                    dr[7] = elem.Attributes["Memo"].Value;
                    dr[8] = elem.Attributes["PlatformCode"].Value;
                    dr[9] = elem.Attributes["Platform"].Value;
                    dr[10] = elem.Attributes["State"].Value;
                    dr[11] = elem.Attributes["Status"].Value;
                    dt.Rows.Add(dr);
                }
                ds.Tables.Add(dt);
            }
            return ds;
        }


        //(RTS)分戶帳銀行帳號查詢 
        public static APIResult GetRtsQueryLedge(string Account, string UserID, string Key, string CID, string IDs, string SubAcc)
        {
            DataTable dt = new DataTable();
            string APIName = "eRtsQueryLedge.aspx";
            string URL = ConfigurationSettings.AppSettings["TSServerPath"].ToString() + APIName;
            WebClient webClient = new WebClient();
            NameValueCollection formData = new NameValueCollection();

            formData.Clear();
            formData["u0"] = Account;
            formData["u1"] = UserID;
            formData["u3"] = Key;
            formData["u5"] = Function.GetClientIP();
            formData["u6"] = CID;
            formData["p0"] = IDs;
            formData["p1"] = SubAcc;

            byte[] responseBytes = webClient.UploadValues(URL, "POST", formData);
            string resultAuthTicket = Encoding.Default.GetString(responseBytes);
            webClient.Dispose();

            StringReader sr = new StringReader(resultAuthTicket);
            DataSet ds = new DataSet();
            ds.ReadXml(sr);
            return DataSetToAPIResult(ds);
        }
        public static APIResult GetRtsQueryLedge(string Account, string UserID, string Key, string CID, string IDs, string SubAcc,string xml) {
            DataTable dt = new DataTable();
            string APIName = "eRtsQueryLedge.aspx";
            string URL = ConfigurationSettings.AppSettings["TSServerPath"].ToString() + APIName;
            WebClient webClient = new WebClient();
            NameValueCollection formData = new NameValueCollection();

            formData.Clear();
            formData["u0"] = Account;
            formData["u1"] = UserID;
            formData["u3"] = Key;
            formData["u5"] = Function.GetClientIP();
            formData["u6"] = CID;
            formData["p0"] = IDs;
            formData["p1"] = SubAcc;

            byte[] responseBytes = webClient.UploadValues(URL, "POST", formData);
            string resultAuthTicket = Encoding.Default.GetString(responseBytes);
            webClient.Dispose();

            StringReader sr = new StringReader(resultAuthTicket);
            DataSet ds = new DataSet();
            if (!string.IsNullOrWhiteSpace(xml)) {
                ds = JoinXMLGetRtsQueryLedge(xml);
            } else {
                ds.ReadXml(sr);
            }
            return DataSetToAPIResult(ds);
        }


        public static DataSet JoinXMLGetRtsQueryLedge(string xmlData) {
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.XmlResolver = null;
            DataSet ds = new DataSet();
            xmlDoc.LoadXml(xmlData);
            if (xmlDoc.SelectNodes("Result/Data").Count > 0) {
                DataTable dt = new DataTable();
                dt.TableName = "Row";
                dt.Columns.Add(new DataColumn("BID", typeof(string)));
                dt.Columns.Add(new DataColumn("SubAcc", typeof(string)));
                dt.Columns.Add(new DataColumn("Name", typeof(string)));
                dt.Columns.Add(new DataColumn("BankNo", typeof(string)));
                dt.Columns.Add(new DataColumn("BankAccount", typeof(string)));
                dt.Columns.Add(new DataColumn("CurrencyCode", typeof(string)));
                dt.Columns.Add(new DataColumn("Currency", typeof(string)));
                dt.Columns.Add(new DataColumn("Balance", typeof(string)));
                dt.Columns.Add(new DataColumn("AvlblBlance", typeof(string)));

                DataRow dr = null;
                XmlNodeList nodeRow = xmlDoc.SelectNodes("Result/Data/Row");
                foreach (XmlNode oData in nodeRow) {
                    XmlElement elem = (XmlElement)oData;
                    dr = dt.NewRow();
                    dr[0] = elem.Attributes["BID"].Value;
                    dr[1] = elem.Attributes["SubAcc"].Value;
                    dr[2] = elem.Attributes["Name"].Value;
                    dr[3] = elem.Attributes["BankNo"].Value;
                    dr[4] = elem.Attributes["BankAccount"].Value;
                    dr[5] = elem.Attributes["CurrencyCode"].Value;
                    dr[6] = elem.Attributes["Currency"].Value;
                    dr[7] = elem.Attributes["Balance"].Value;
                    dr[8] = elem.Attributes["AvlblBlance"].Value;
                    dt.Rows.Add(dr);
                }
                ds.Tables.Add(dt);
            }
            return ds;
        }


        //(RTS)分戶帳交易明細查詢
        public static APIResult GetRtsLedgeDetail(string Account, string UserID, string CID, string IDs, string SubAcc, string StartDate, string EndDate, string xml) {
            DataTable dt = new DataTable();
            string APIName = "eRtsLedgeDetail.aspx";
            string URL = ConfigurationSettings.AppSettings["TSServerPath"].ToString() + APIName;
            WebClient webClient = new WebClient();
            NameValueCollection formData = new NameValueCollection();

            formData.Clear();
            formData["u0"] = Account;
            formData["u1"] = UserID;
            formData["u5"] = Function.GetClientIP();
            formData["u6"] = CID;
            formData["p0"] = IDs;
            formData["p1"] = SubAcc;
            formData["p2"] = StartDate;
            formData["p3"] = EndDate;



            byte[] responseBytes = webClient.UploadValues(URL, "POST", formData);
            string resultAuthTicket = Encoding.Default.GetString(responseBytes);
            webClient.Dispose();

            StringReader sr = new StringReader(resultAuthTicket);
            DataSet ds = new DataSet();
            ds.ReadXml(sr);//2019.01.4

            //2019.01.4
            //XmlDocument eRtsQueryLedge4 = new XmlDocument();
            //eRtsQueryLedge4.Load(xml);
            //XmlReader Xmlreader = XmlReader.Create(new System.IO.StringReader(xml));
            //ds.ReadXml(Xmlreader);

            //2019.01.4

            return DataSetToAPIResult(ds);
        }

        public static string GenDropSettlementAccount(DropDownList drpSAccount, DataTable QueryLedge,bool visble)
        {
			//取得UserInfo,但不延長cookie的時間
			ListItem ltn;
			if(visble)
				drpSAccount.Items.Add(new ListItem("全部", "all"));
			for (int i = 0; i < QueryLedge.Rows.Count; i++)
			{
				ltn = new ListItem();
				ltn.Value = string.Format("{0}", QueryLedge.Rows[i].ItemArray[1].ToString());
				ltn.Text = string.Format("{0} {1}", QueryLedge.Rows[i].ItemArray[1].ToString(), QueryLedge.Rows[i].ItemArray[2].ToString());
				drpSAccount.Items.Add(ltn);
			}
			drpSAccount.Attributes["onchange"] = "setSACookie('" + drpSAccount.ClientID + "');";


			if (drpSAccount != null)
			{
				if (drpSAccount.Items != null)
				{
					if (GetTrading.CookieValue("EnCodeSA_SubAcc") == "" || GetTrading.CookieValue("EnCodeSA_SubAcc") == "all")
					{
						
					}
					else
					{
						drpSAccount.SelectedValue = GetTrading.CookieValue("EnCodeSA_SubAcc");				
					}

					if (drpSAccount.Items.Count > 0)
						return drpSAccount.SelectedItem.Text;
				}
			}
			return "[無交易帳號]";
		}


        public static string SiteLogOutJS()
        {

            // Put user code to initialize the page here


            //SSWSHelper.ClearSession(GetTrading.CurrentSSID());

            //網頁自動登出,要把開啟的報價window 關閉
            //GetTrading.WriteCookie("VIPLogOut", "OK");
            //string strVIPPath = ConfigurationSettings.AppSettings["VIPPath"];
            StringBuilder aScript = new StringBuilder();
            //aScript.Append(@"<script language='javascript' src='" + strVIPPath + "vipaspex/LogOut.asp'></script>");
            aScript.Append(@"<script language='javascript'>");
            aScript.Append(@"document.cookie = 'CAReset=; expires=Wed, 01-Jan-2003 00:00:01 UTC';");
            aScript.Append(@"var oEnlarge = top.oEnlarge;");
            aScript.Append(@"if (typeof(oEnlarge)!= 'undefined' && oEnlarge != null) {");
            aScript.Append(@"oEnlarge.close();");
            aScript.Append(@"oEnlarge = null ;");
            aScript.Append(@"}");
            //假如頁面是開出來的話,登出時要指回父視窗才會對,並把視窗close
            aScript.Append(@"if(typeof(window.dialogArguments) != 'undefined'){");
            aScript.Append(@"window.dialogArguments.top.document.location = '../Login.aspx';");
            aScript.Append(@"window.close();}");
            aScript.Append(@"else{");
            aScript.Append(@"window.top.document.location = '../Login.aspx';}");
            aScript.Append("</script>");

            return aScript.ToString();
        }

        private static APIResult DataSetToAPIResult(DataSet ds)
        {
            DataTable dt = new DataTable();
            APIResult apiResult = new APIResult();
            if (ds != null && ds.Tables.Count > 0 && ds.Tables["Row"] != null && ds.Tables["Row"].Rows.Count > 0)
            {
                dt = ds.Tables["Row"];
                apiResult.rawData = dt;
            }

            if (ds != null && ds.Tables.Count > 0 && ds.Tables["Result"] != null && ds.Tables["Result"].Rows.Count > 0)
            {
                apiResult.serverTime = ds.Tables["Result"].Rows[0].ItemArray[2].ToString();
            }

            if (ds != null && ds.Tables.Count > 0 && ds.Tables["error"] != null && ds.Tables["error"].Rows.Count > 0)
            {
                apiResult.errorName = ds.Tables["error"].Rows[0].ItemArray[2].ToString();
            }

            return apiResult;
        }


        public static string TimeFormatTrans(string serverTime)
        {
            string sYear = serverTime.Split('-')[0].Substring(0, 4);
            string sMonth = serverTime.Split('-')[0].Substring(4, 2);
            string sDay = serverTime.Split('-')[0].Substring(6, 2);
            string sHour = serverTime.Split('-')[1].Substring(0, 2);
            string sMinute = serverTime.Split('-')[1].Substring(2, 2);
            string sSecond = serverTime.Split('-')[1].Substring(4, 2);
            return sYear + "/" + sMonth + "/" + sDay + " " + sHour + ":" + sMinute;
            //return sYear + "/" + sMonth + "/" + sDay + " " + sHour + ":" + sMinute + ":" + sSecond;
        }


        public static DataTable SplitDataTable(DataTable dt, int PageIndex, int PageSize) {
            if (dt == null) {
                return null;
            }
            if (PageIndex == 0)
                return dt;
            DataTable newdt = dt.Clone();
            //newdt.Clear();
            int rowbegin = (PageIndex - 1) * PageSize;
            int rowend = PageIndex * PageSize;

            if (rowbegin >= dt.Rows.Count)
                return newdt;

            if (rowend > dt.Rows.Count)
                rowend = dt.Rows.Count;
            for (int i = rowbegin; i <= rowend - 1; i++) {
                DataRow newdr = newdt.NewRow();
                DataRow dr = dt.Rows[i];
                foreach (DataColumn column in dt.Columns) {
                    newdr[column.ColumnName] = dr[column.ColumnName];
                }
                newdt.Rows.Add(newdr);
            }

            return newdt;
        }

        public static float StrToFloat(object FloatString) {
            try {
                float f = (float)Convert.ToSingle(FloatString);
                return f;
            }
            catch (FormatException) {
                return (float)0.00;
            }
        }


    }


   
}