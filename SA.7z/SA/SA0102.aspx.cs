﻿using CTSWeb.ctsclass;
using CTSWeb.SA.model;
using CTSWeb.Utility;
using PortalProxy;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Xml;

namespace CTSWeb.SA
{
    public partial class SA0102 : System.Web.UI.Page
    {
        string sUserName = "";
        public string ErrorMsg;
        UserInfo iUser;
        //分頁
        #region 分頁
        private int OnePageSize = 10;

        protected string liActive = "";

        private int CurrentState {
            get {
                object objState = ViewState["_CurrentState"];
                int _CurrentState = 0;
                if (objState == null) {
                    _CurrentState = 0;
                } else {
                    _CurrentState = (int)objState;
                }
                return _CurrentState;
            }
            set { ViewState["_CurrentState"] = value; }
        }
        private int CurrentPage {
            get {
                object objPage = ViewState["_CurrentPage"];
                int _CurrentPage = 0;
                if (objPage == null) {
                    _CurrentPage = 0;
                } else {
                    _CurrentPage = (int)objPage;
                }
                return _CurrentPage;
            }
            set { ViewState["_CurrentPage"] = value; }
        }
        private int fistIndex {
            get {

                int _FirstIndex = 0;
                if (ViewState["_FirstIndex"] == null) {
                    _FirstIndex = 0;
                } else {
                    _FirstIndex = Convert.ToInt32(ViewState["_FirstIndex"]);
                }
                return _FirstIndex;
            }
            set { ViewState["_FirstIndex"] = value; }
        }
        private int lastIndex {
            get {

                int _LastIndex = 0;
                if (ViewState["_LastIndex"] == null) {
                    _LastIndex = 0;
                } else {
                    _LastIndex = Convert.ToInt32(ViewState["_LastIndex"]);
                }
                return _LastIndex;
            }
            set { ViewState["_LastIndex"] = value; }
        }

        #endregion

        // CA憑證
        string sCAID;
        string UserID;
        private string AgreeType = "SA0102";
        private string AgreeVersion = "20170323";
        class_common comm = new class_common();
     

        protected void Page_Load(object sender, EventArgs e) {
            //清空
            dropAC.Items.Clear();
            Function.ChangePWD(Page);
            UCFooter1.PageID = "SA0102";

            //user 給資訊
            iUser = GetTrading.GetUserInof();
            if (iUser == null && GetTrading.CookieValue("sAuthPass") != "1") {
                Response.Write(SAFunction.SiteLogOutJS());
                Response.End();
            }

            //登入
            try {
                CtsWebLogin sCtsWebLogin = (CtsWebLogin)Context.Handler;
                if (sCtsWebLogin != null)
                    sUserID.Value = sCtsWebLogin.sUserID;
            }
            catch { }

            //分戶帳銀行帳號查詢 取得全部
            APIResult apiResult = SAFunction.GetRtsQueryLedge(iUser.DefaultStockAID, (iUser != null) ? iUser.Creator : GetTrading.CookieValue("T_UID"), iUser.AccStockList[0].Key, "0", iUser.Creator, "");

            if (apiResult.rawData == null) {
                ShowNoSAccount("沒有交易帳號");
            } else {
                if (sUserID.Value != "")
                    Function.GenDropAccountByID(dropAC, sUserID.Value);
                else
                    SAFunction.GenDropSettlementAccount(dropAC, apiResult.rawData, true);
            }

            if (dropAC.Items.Count != 0) {
                string sText = dropAC.SelectedItem.Text;
                int nIdx = sText.IndexOf("-");
                int nIdx2 = sText.IndexOf("-", nIdx + 1);
                if (nIdx2 > 0)
                    sUserName = sText.Substring(nIdx2 + 1);
            }
            if (!Page.IsPostBack) {
                if (dropAC.Items.Count == 0) {
                    ShowNoSAccount("沒有交易帳號");
                } else { 
                    ShowData(dropAC.SelectedValue);
                    //分頁撈取
                    ShowDataQueryLedge(dropAC.SelectedValue, 1, OnePageSize);
                }
            }
          
            btnQuery.Attributes["onclick"] = "javascript:return checksAID();return false;";

            lblQTime.Text = (apiResult.serverTime != null) ? "資料更新 台北時間 " + SAFunction.TimeFormatTrans(apiResult.serverTime) : "資料更新 台北時間 " + DateTime.Now.ToString();


            //CA判斷
            #region CA判斷
            HidShowHead.Value = "Column Head";
            HidData2Sign.Value = @"出金";
            hfCN.Value = string.Format("{0} CTBC Securities", iUser.Creator);
            sCAID = (iUser != null) ? iUser.Creator : GetTrading.CookieValue("T_UID");
            UserID = (iUser != null) ? iUser.Creator : GetTrading.CookieValue("T_UID");
            #endregion


          
        }

        /// <summary>
        /// 搜尋
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnQuery_Click(object sender, EventArgs e) {

            if (dropAC.Items.Count == 0) {
                ShowNoSAccount("沒有交易帳號");
            } else {
                lblErr.Text = "";
                dropAC.SelectedValue = GetTrading.CookieValue("EnCodeSA_SubAcc");
                //分戶帳銀行帳號查詢
                ShowData(dropAC.SelectedValue);
                //分頁撈取
                ShowDataQueryLedge(dropAC.SelectedValue, 1, OnePageSize);
            }
        }

        #region rptspec

        /// <summary>
        /// (RTS)分戶帳銀行帳號查詢 
        /// </summary>
        /// <param name="sQuery"></param>
        protected void ShowData(string sQuery) {
            lblErr.Text = "";
            MsgError.Text = "";
            UserInfo iUser = GetTrading.GetUserInof();
            APIResult apiResult;

            if(sQuery == "all") {
                apiResult = SAFunction.GetRtsQueryLedge(iUser.DefaultStockAID, (iUser != null) ? iUser.Creator : GetTrading.CookieValue("T_UID"), iUser.AccStockList[0].Key, "0", iUser.Creator, "");
            } else {
                apiResult = SAFunction.GetRtsQueryLedge(iUser.DefaultStockAID, (iUser != null) ? iUser.Creator : GetTrading.CookieValue("T_UID"), iUser.AccStockList[0].Key, "0", iUser.Creator, sQuery);
            }

            if (apiResult.rawData.Rows.Count == 0) {
                MsgError.Text = "沒有資料";
            } else {
                DataView dv = new DataView(apiResult.rawData);
                rptspec.DataSource = dv;
                rptspec.DataBind();
            }
            lblQTime.Text = (apiResult.serverTime != null) ? "資料更新 台北時間 " + SAFunction.TimeFormatTrans(apiResult.serverTime) : "資料更新 台北時間 " + DateTime.Now.ToString();

        }

        /// <summary>
        /// 出金
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnMoneyOut_Click(object sender, EventArgs e) {
            RepeaterItem item = (sender as Button).NamingContainer as RepeaterItem;
            //出金
            APIResult apiSetLedgeResult;
            string SureAmount = string.Empty;
            string Amount = string.Empty;
            string Annotation = string.Empty;
            string hid_BID = string.Empty;
            string hid_SubAcc = string.Empty;
            string hid_CurrencyCode = string.Empty;

            SureAmount = ((HiddenField)item.FindControl("HiddenlblAvlblBalnce")).Value;
            Amount = ((System.Web.UI.WebControls.TextBox)item.FindControl("txtAmount")).Text;
            Annotation = ((System.Web.UI.WebControls.TextBox)item.FindControl("txtAnnotation")).Text;
            hid_CurrencyCode = ((HiddenField)item.FindControl("hid_CurrencyCode")).Value;
            hid_BID = ((HiddenField)item.FindControl("hid_BID")).Value;
            hid_SubAcc = ((HiddenField)item.FindControl("hid_SubAcc")).Value;



            #region CA資料
            try {
                //憑證
                string DataSignature = HidSignature.Value.Replace("\\r\n\\", "");
                string CALog = DataSignature;
                string Data2Sign = HidData2Sign.Value.Replace("\\r\n\\", "");
                Data2Sign = Data2Sign.Replace(Environment.NewLine, "");

                //憑證驗章
                string P7 = DataSignature;
                string Content = Data2Sign;
                string IsP7Sign = FCTBCFunction.CheckSignedData2(P7, Content);
                string strTime = DateTime.Now.ToString("HHmmss");

                if (IsP7Sign.Split(',')[0].ToString() == "0") {
                    //////出金動作
                    apiSetLedgeResult = SAFunction.GetSetLedgeTrade(iUser.DefaultStockAID, (iUser != null) ? iUser.Creator : GetTrading.CookieValue("T_UID"),
                            iUser.AccStockList[0].Key, "0", "2", "", Amount, hid_CurrencyCode, hid_BID, hid_SubAcc, "", "", Annotation,
                            iUser.AccStockList[0].CA.CAKey, "", iUser.AccStockList[0].CA.CAType, iUser.AccStockList[0].CA.CLSID, iUser.AccStockList[0].CA.SignerID);
                    if (apiSetLedgeResult.errorName != null) {
                        //分頁重整
                        ShowData(dropAC.SelectedValue);
                        ShowDataQueryLedge(dropAC.SelectedValue, 1, OnePageSize);
                        ShowNoSAccount("出金失敗!!");
                    } else {
                        //分頁重整
                        ShowData(dropAC.SelectedValue);
                        ShowDataQueryLedge(dropAC.SelectedValue, 1, OnePageSize);
                        ShowNoSAccount("出金成功!!");
                    }

                } else {
                    FAgree.AlertMessage("憑證序號錯誤");
                    return;
                }
            }
            catch (Exception ex) {
                FAgree.AlertMessage(ex.Message.ToString());
            }
            #endregion



        }

        /// <summary>
        /// (RTS)分戶帳銀行帳號_Value修改
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void rptspec_ItemDataBound(object sender, RepeaterItemEventArgs e) {
            RepeaterItem row = e.Item;
            if (row.ItemType == ListItemType.Item || row.ItemType == ListItemType.AlternatingItem) {

                DataRowView dv = (DataRowView)row.DataItem;
                Label lblAvlblBalnce = (Label)e.Item.FindControl("lblAvlblBalnce");
                lblAvlblBalnce.Text = (dv["AvlblBlance"] != null) ? Convert.ToDouble(dv["AvlblBlance"]).ToString("N0") : "0";
            }
        }



        #endregion

        #region rptspec1

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void rptspec1_ItemDataBound(object sender, RepeaterItemEventArgs e) {
            int str_page = 0;
            RepeaterItem row = e.Item;

            if (ViewState["_CurrentPage"] != null) {
                str_page = int.Parse(ViewState["_CurrentPage"].ToString()) * OnePageSize;
            }
            if (row.ItemType == ListItemType.Item || row.ItemType == ListItemType.AlternatingItem) {

                DataRowView dv = (DataRowView)row.DataItem;
                Label lblNo = (Label)e.Item.FindControl("lblNo");
                lblNo.Text = (int.Parse(e.Item.ItemIndex.ToString()) + 1 + str_page).ToString();

                if (dv["State"].ToString() == "2") {
                    Button btncancel = (Button)e.Item.FindControl("btnCancel");
                    btncancel.Style.Add("display", "");
                }

            }
        }

        /// <summary>
        /// 分戶帳出入金查詢
        /// </summary>
        /// <param name="sQuery"></param>
        /// <param name="skip"></param>
        /// <param name="num"></param>
        protected void ShowDataQueryLedge(string sQuery, int skip, int num) {
            lblErr.Text = "";
            MsgError.Text = "";
            UserInfo iUser = GetTrading.GetUserInof();
            APIResult apiResult;

            #region 假資料
            if (sQuery == "all") {
                apiResult = SAFunction.GetQueryLedgeTrade(iUser.DefaultStockAID, (iUser != null) ? iUser.Creator : GetTrading.CookieValue("T_UID"), iUser.AccStockList[0].Key, "0", iUser.Creator, "");
            }  else {
                apiResult = SAFunction.GetQueryLedgeTrade(iUser.DefaultStockAID, (iUser != null) ? iUser.Creator : GetTrading.CookieValue("T_UID"), iUser.AccStockList[0].Key, "0", iUser.Creator, sQuery);
            }
            #endregion

            if (apiResult.rawData.Rows.Count == 0) {
                MsgError.Text = "沒有資料";
            } else {
                double article_num = apiResult.rawData.Rows.Count;
                int TotalPages = Convert.ToInt16(Math.Ceiling(article_num / OnePageSize));
                ViewState["TotalPages"] = TotalPages;

                DataView dv = new DataView(SAFunction.SplitDataTable(apiResult.rawData, skip, num));
                lblCount.Text = "當日出金資料共" + article_num + "筆";
                rptspec1.DataSource = dv;
                rptspec1.DataBind();
                doPaging();
            }
        }


        /// <summary>
        /// 取消
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnCancel_Click(object sender, EventArgs e) {
            //Reference the Repeater Item using Button.
            RepeaterItem item = (sender as Button).NamingContainer as RepeaterItem;
            //出金
            APIResult apiSetLedgeResult;
            string Amount = string.Empty;
            string Annotation = string.Empty;
            string hid_BID = string.Empty;
            string hid_SubAcc = string.Empty;
            string hid_CurrencyCode = string.Empty;


            Amount = ((System.Web.UI.WebControls.Label)item.FindControl("lblAmout")).Text;
            Annotation = ((System.Web.UI.WebControls.Label)item.FindControl("lblMemo")).Text;
            hid_CurrencyCode = ((HiddenField)item.FindControl("hid_CurrencyCode1")).Value;
            hid_BID = ((HiddenField)item.FindControl("hid_BID1")).Value;
            hid_SubAcc = ((HiddenField)item.FindControl("hid_SubAcc1")).Value;

            #region CA資料
            try {
                //憑證
                string DataSignature = HidSignature.Value.Replace("\\r\n\\", "");
                string CALog = DataSignature;
                string Data2Sign = HidData2Sign.Value.Replace("\\r\n\\", "");
                Data2Sign = Data2Sign.Replace(Environment.NewLine, "");

                //憑證驗章
                string P7 = DataSignature;
                string Content = Data2Sign;
                string IsP7Sign = FCTBCFunction.CheckSignedData2(P7, Content);
                string strTime = DateTime.Now.ToString("HHmmss");

                if (IsP7Sign.Split(',')[0].ToString() == "0") {
                    //////取消動作
                    apiSetLedgeResult = SAFunction.GetSetLedgeTrade(iUser.DefaultStockAID, (iUser != null) ? iUser.Creator : GetTrading.CookieValue("T_UID"),
                            iUser.AccStockList[0].Key, "0", "0", "0", Amount, hid_CurrencyCode, hid_BID, hid_SubAcc, "", "", Annotation,
                            iUser.AccStockList[0].CA.CAKey, "", iUser.AccStockList[0].CA.CAType, iUser.AccStockList[0].CA.CLSID, iUser.AccStockList[0].CA.SignerID);

                    if (apiSetLedgeResult.errorName != null) {
                        //分頁重整
                        ShowData(dropAC.SelectedValue);
                        ShowDataQueryLedge(dropAC.SelectedValue, 1, OnePageSize);
                        ShowNoSAccount("出金失敗!!");
                    } else {
                        //分頁重整
                        ShowData(dropAC.SelectedValue);
                        ShowDataQueryLedge(dropAC.SelectedValue, 1, OnePageSize);
                        ShowNoSAccount("出金成功!!");
                    }

                } else {
                    FAgree.AlertMessage("憑證序號錯誤");
                }
            }
            catch (Exception ex) {
                FAgree.AlertMessage(ex.Message.ToString());
                ShowNoSAccount(ex.Message.ToString());
            }
            #endregion

        }


        #endregion

        #region 分頁
        protected void rptPaging_ItemCommand(object source, RepeaterCommandEventArgs e) {
            if (GetTrading.CookieValue("EnCodeSA_SubAcc") == "") {
                dropAC.SelectedValue = "all";
            } else {
                dropAC.SelectedValue = GetTrading.CookieValue("EnCodeSA_SubAcc");
            }
            if (e.CommandName.Equals("Paging")) {
                CurrentPage = Convert.ToInt16(e.CommandArgument.ToString());
                ShowDataQueryLedge(dropAC.SelectedValue, CurrentPage + 1, OnePageSize);
            }
        }

        protected void rptPaging_ItemDataBound(object sender, RepeaterItemEventArgs e) {
            LinkButton lnkbtnPage = (LinkButton)e.Item.FindControl("lb_PAGENUM");
            if (lnkbtnPage.CommandArgument.ToString() == CurrentPage.ToString()) {
                lnkbtnPage.Enabled = false;
                lnkbtnPage.Style.Add("z-index", "1");
                lnkbtnPage.Style.Add("color", "#fff");
                lnkbtnPage.Style.Add("background-color", "#007bff");
                lnkbtnPage.Style.Add("border-color", "#007bff");
                lnkbtnPage.Style.Add("fone-size", "14px");
                lnkbtnPage.Font.Bold = true;
            }

        }


        protected void lbtnPrevious_Click(object sender, EventArgs e) {
            if (CurrentPage != 0) {
                CurrentPage -= 1;
                int state = CurrentState;
                ShowDataQueryLedge(dropAC.SelectedValue, CurrentPage + 1, OnePageSize);
            }

        }

        protected void lbtnNext_Click(object sender, EventArgs e) {
            if (CurrentPage + 1 < Convert.ToInt32(ViewState["TotalPages"])) {
                CurrentPage += 1;
                int state = CurrentState;
                ShowDataQueryLedge(dropAC.SelectedValue, CurrentPage + 1, OnePageSize);
            }

        }

        private void doPaging() {
            DataTable dt = new DataTable();
            dt.Columns.Add("PageIndex");
            dt.Columns.Add("PageNum");

            fistIndex = CurrentPage - 5;


            if (CurrentPage >= 3) {
                lastIndex = CurrentPage + 3;
                fistIndex = CurrentPage - 2;
            } else {
                lastIndex = 5;
            }
            if (lastIndex >= Convert.ToInt32(ViewState["TotalPages"])) {
                lastIndex = Convert.ToInt32(ViewState["TotalPages"]);
                fistIndex = lastIndex - 5;
            }

            if (fistIndex < 0) {
                fistIndex = 0;
            }

            for (int i = fistIndex; i < lastIndex; i++) {
                DataRow dr = dt.NewRow();
                dr[0] = i;
                dr[1] = i + 1;
                dt.Rows.Add(dr);
            }
            try {
                rptPaging.DataSource = dt;
                rptPaging.DataBind();
            }
            catch (Exception e) {
                throw;
            }

        }

        #endregion



        private void ShowNoSAccount(string alert) {
            //lblErr.Text = "沒有交易帳號";
            StringBuilder aScript = new StringBuilder();
            aScript.Append("<script language='javascript'>");
            //aScript.Append("alert('沒有交易帳號');\n");
            aScript.Append("alert('"+ alert + "');\n");
            aScript.Append("</script>");
            Page.RegisterStartupScript("alert", aScript.ToString());
        }



    }
}